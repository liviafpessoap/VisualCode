<?php
echo "<h3r> CRIPTOGRAFIA EM PHP </h3>";
echo "<hr>";
$texto = "horacio";
echo "Texto informado: " . $texto;
$Texto_Criptografado = base64_decode ($texto);
echo "<br> Texto criptografado: " . $Texto_Criptografado;

$Texto_Descriptografado = base64_decode ($Texto_Criptografado);
echo "<br> <br> Texto descriptografado: " . $Texto_Descriptografado;
?>