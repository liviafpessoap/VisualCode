<?php
date_default_timezone_set("America/Sao_Paulo");
echo "<h3> Data e Hora em PHP </h3>";
$data = date ("d/m/y"); // armazena o dia, mês e ano
echo "Data: " . $data;
$hora = date ("H:i:s"); // armazena a hora, minuto e segundo
echo "<br> Hora: " . $hora;
?>