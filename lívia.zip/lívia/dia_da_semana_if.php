<?php
echo "<h4> ESTRUTURA CONDICIONAL IF EM PHP </h4> <hr>";
$Dia_Semana = date ("w");
$Dia_Extenso = "";
if ($Dia_Semana == 1) {
    $Dia_Extenso = "Domingo";
}
else if ($Dia_Semana == 2) {
    $Dia_Extenso = "Segunda-Feira";
}
else if ($Dia_Semana == 3) {
    $Dia_Extenso = "Terça-Feira";
}
else if ($Dia_Semana == 4) {
    $Dia_Extenso = "Quarta-Feira";
}
else if ($Dia_Semana == 5) {
    $Dia_Extenso = "Quinta-Feira";
}
else if ($Dia_Semana == 6) {
    $Dia_Extenso = "Sexta-Feira";
}
else if ($Dia_Semana == 7) {
    $Dia_Extenso = "Sábado";
}
echo "<strong> Hoje é: </strong>"  $Dia_Extenso;
?>