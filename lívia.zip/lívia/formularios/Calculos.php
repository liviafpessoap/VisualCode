<h4>SOMA DE 2 NÚMEROS</h4>
<form action="exibir_calculo.php" method="POST">
<label>Número1: </label>
<input type="text" name="num1" size="5" maxlength="4" required><br>
<label>Número2: </label>
<input type="text" name="num2" size="5" maxlength="4" required><br><br>
<input type="submit" value="Somar">
<input type="reset" value="Limpar">
</form>

