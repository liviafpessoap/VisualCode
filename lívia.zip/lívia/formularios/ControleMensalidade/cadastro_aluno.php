<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Cadastro de Aluno </h3>
    <form name = "aluno" method = "post" action = "">
        <label> Nome:</label>
        <input type = "text" name = "nome" size = "30" maxlength = "50" required> <br>
        <label> Cidade:</label>
        <input type = "text" name = "cidade" size = "30" maxlength = "30" required> <br>
        <label> Email: </label>
        <input type = "text" name = "email" size = "30" maxlength = "30" required> <br>
        <input type = "submit" name = "cadastrar" value = "Cadastrar" class = "btn btn-primary">
        <a href = "index.php" class = "btn btn-danger"> Retornar </a>
    </form>
</div>
<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        require "conexao.php";
        $nome     =  $_POST ['nome'];
        $cidade   =  $_POST ['cidade'];
        $email    =  $_POST ['email'];
        $sql = "INSERT INTO tbaluno (aluno, cidade, email) VALUES ('$nome', '$cidade', '$email')";        
        mysqli_query ($conexao, $sql) or die (mysqli_error($conexao));  // faz a inserção no banco de dados; "or die" é uma função que exibe uma mensagem de erro caso o query apresente falha        
        mysqli_close($conexao);  // fecha a conexão com o banco de dados
        echo "<script> alert ('Aluno cadastrado com sucesso'); </script>";
        echo "<script> window.location.href = window.location.href; </script>";  // recarrega a pagina
    }
?>