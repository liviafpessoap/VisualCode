<?php
$host    =  "localhost";
$user    =  "root";
$pass    =  "";
$banco   =  "bdmensalidade";
$conexao = mysqli_connect($host, $user, $pass) or die ("Erro ao conectar no servidor");
mysqli_select_db($conexao, $banco) or die ("Erro ao selecionar o banco de dados");
mysqli_set_charset($conexao, "utf8");
?>