<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Editar Aluno </h3>
    <?php
    require "conexao.php";
    $codigo = $_REQUEST['codigo'];
    $sql = "SELECT * FROM tbaluno WHERE codigo = $codigo";
    $resultado = mysqli_query($conexao, $sql) or die (mysqli_error ($conexao));
    $linha = mysqli_fetch_array($resultado);
    $codigo  =  $linha ['codigo'];
    $aluno   =  $linha ['aluno'];
    $cidade  =  $linha ['cidade'];
    $email   =  $linha ['email'];

    echo "<form name = 'aluno' action = '' method = 'POST'>";
        echo "<table border = '1'>";
            echo "<tr>";
                echo "<td> <label> Código: </label> </td>";
                echo "<td> <input type = 'text' name = 'codigo' size = '5' maxlength = '5' value = '$codigo' readonly> </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td> <label> Aluno: </label> </td>";
                echo "<td> <input type = 'text' name = 'aluno' size = '30' maxlength = '50' value = '$aluno' required> </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td> <label> Cidade: </label> </td>";
                echo "<td> <input type = 'text' name = 'cidade' size = '30' maxlength = '30' value = '$cidade' required> </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td> <label> Email: </label> </td>";
                echo "<td> <input type = 'text' name = 'email' size = '30' maxlength = '50' value = '$email' required> </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td colspan = '2' align = 'center'> <input type = 'submit' value = 'Editar' class = 'btn btn-primary mr-2'>";
                echo "<a href = 'pesquisa_alunos.php' class = 'btn btn-danger'> Retornar </a> </td>";
            echo "</tr>";
        echo "</table>";
    echo "</form>";

    ?>

    <?php
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        require "conexao.php";
        $codigo  =  $_POST ["codigo"];
        $aluno   =  $_POST ["aluno"];
        $cidade  =  $_POST ["cidade"];
        $email   =  $_POST ["email"];
        $sql = "UPDATE tbaluno SET aluno = '$aluno', cidade = '$cidade', email = '$email' WHERE codigo = '$codigo'";

        mysqli_query($conexao, $sql) or die (mysqli_error($conexao));

        // fecha a conexão com o banco de dados
        mysqli_close($conexao);
        echo "<script> alert ('Aluno salvo com sucesso'); </script>";
        echo "<a href = 'index.php' class = btn btn-danger'> Retornar </a>";
    }

    ?>
</div>