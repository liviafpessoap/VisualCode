<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Editar Mensalidade </h3>
    <?php

    require "conexao.php";
    $mensalidade = $_REQUEST['mensalidade'];
    $sql = "SELECT * FROM tbmensalidade WHERE mensalidade = $mensalidade";
    $resultado = mysqli_query($conexao, $sql) or die (mysqli_error ($conexao));
    $linha = mysqli_fetch_array($resultado);
    $codaluno     =  $linha ['codaluno'];
    $mes          =  $linha ['mes'];
    $curso        =  $linha ['curso'];
    $valor        =  $linha ['valor'];
    $vlpagamento  =  $linha ['vlpagamento'];
    $dtpagamento  =  $linha ['dtpagamento'];
    $situacao     =  $linha ['situacao'];

    echo "<form name = 'mensalidade' action = '' method = 'POST'>";
        echo "<table border = '1' align = 'center' cellpadding = '4'>";
            echo "<tr>";
            echo "<th> <label> Mensalidade: </label> </th>";
            echo "<td> <input type = 'number' name = 'mensalidade' size = '5' maxlength = '5' value = '$mensalidade' readonly> </td>";
            echo "</tr>";
            echo "<tr>";
            echo "<th> <label> Aluno: </label> </th>";
            echo "<td> <input type = 'number' name = 'codaluno' min = '1' value = '$codaluno'> </td>"; 
            echo "</tr>";
            echo "<tr>";
            echo "<th> <label> Mês: </label> </th>";
            echo "<td> <input type = 'number' name = 'mes' min = '1' value = '$mes'> </td>";
            echo "</tr>";
            echo "<tr>";
            echo "<th> <label> Curso: </label> </th>";
            echo "<td> <input type = 'text' name = 'curso' size = '50' maxlength = '100' value = '$curso'> </td>";
            echo "</tr>";
            echo "<tr>";
            echo "<th> <label> Valor: </label> </th>";
            echo "<td> <input type = 'number' name = 'valor' min = '1' value = '$valor' step = '0.01'> </td>";
            echo "</tr>";
            echo "<tr>";
            echo "<th> <label> Valor do pagamento: </label> </th>";
            echo "<td> <input type = 'number' name = 'vlpagamento' min = '1' value = '$vlpagamento' step = '0.01'> </td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td colspan = '2' align = 'center'> <input type = 'submit' value = 'Editar' class = 'btn btn-primary mr-2'>";
            echo "<a href = 'pesquisa_mensalidade.php' class = 'btn btn-danger'> Retornar </a> </td>";
            echo "</tr>";
        echo "</table>";
    echo "</form>";

    ?>

    <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            require "conexao.php";
            $mensalidade  =  $linha ['mensalidade'];
            $codaluno     =  $linha ['codaluno'];
            $mes          =  $linha ['mes'];
            $curso        =  $linha ['curso'];
            $valor        =  $linha ['valor'];
            $vlpagamento  =  $linha ['vlpagamento'];
            $dtpagamento  =  $linha ['dtpagamento'];
            $situacao     =  $linha ['situacao'];
            $sql = "UPDATE tbmensalidade SET codaluno = '$codaluno', mes = '$mes', curso = '$curso', valor = '$valor', vlpagamento = '$vlpagamento', dtpagamento = '$dtpagamento' WHERE mensalidade = '$mensalidade'";

            mysqli_query($conexao, $sql) or die (mysqli_error($conexao));
            mysqli_close($conexao);
            echo "<script> alert ('Mensalidade alterada com sucesso'); </script>";
        }
    ?>

</div>