<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
    a
    {
        color: brown;
        font-size: 20px;
        text-transform: uppercase;
        font-family: Impact;
    }
    a:hover
    {
        background-color: white;
        color: blue;
    }
</style>

<div class = "container">
    <a href = "sobre.php"> Sobre </a> |
    <a href = "cadastro_aluno.php"> Cadastro </a> |
    <a href = "pesquisa_alunos.php"> Pesquisa de Alunos </a> |
    <a href = "mensalidade.php"> Mensalidade </a> |
    <a href = "pesquisa_mensalidade.php"> Pesquisa de Mensalidade </a> |
    <a href = "contato.php"> Contato </a> |
    <br>
    <br>
    <h3 class = "text-center text-primary"> Controle de Mensalidades </h3>
    <h3 class = "text-center"> <img src = "Imagens/tralalerotralala.png" alt = "Tralalero Tralala" width = "400" heigth = "400"> </h3>
</div>