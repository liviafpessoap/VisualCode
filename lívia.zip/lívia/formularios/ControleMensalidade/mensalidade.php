<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Lançamento de Mensalidade </h3>
    <form name = "mensalidade" method = "post" action = "">>
        <label> Aluno: </label> <br>
        <input type = "number" name = "aluno" required> <br> <br> 
        <label> Mês: </label> <br>
        <select name = "mes">
            <option value = "1"> Janeiro </option>
            <option value = "2"> Fevereiro </option>
            <option value = "3"> Março </option>
            <option value = "4"> Abril </option>
            <option value = "5"> Maio </option>
            <option value = "6"> Junho </option>
            <option value = "7"> Julho </option>
            <option value = "8"> Agosto </option>
            <option value = "9"> Setembro </option>
            <option value = "10"> Outubro </option>
            <option value = "11"> Novembro </option>
            <option value = "12"> Dezembro </option>
        </select> <br> <br>
        <label> Curso: </label> <br>
        <select name = "curso">
            <option value = "Tec Administração"> Tec Administração </option>
            <option value = "Tec Computação Gráfica"> Tec Computação Gráfica </option>
            <option value = "Tec Contabilidade"> Tec Contabilidade </option>
            <option value = "Tec Fisioterapia"> Tec Fisioterapia </option>
            <option value = "Tec Gastronomia"> Tec Gastronomia </option>
            <option value = "Tec Informática"> Tec Informática </option>
            <option value = "Tec Logística"> Tec Logística </option>
            <option value = "Tec RH"> Tec RH </option>
            <option value = "Costura"> Costura </option>
            <option value = "Estética"> Estética </option>
            <option value = "Desenho"> Desenho </option>
        </select> <br> <br>
        <label> Valor: </label> <br>
        <input type = "number" name = "valor" step = "0.01" required> <br> <br>
        <label> Valor do pagamento: </label> <br>
        <input type = "number" name = "vlpagamento" required> <br> <br>
        <label> Data do pagamento: </label> <br>
        <input type = "text" name = "dtpagamento" required> <br> <br>
        <label> Situação: </label> <br>
        <select name = "situacao">
            <option value = "Pendente"> Pendente </option>
            <option value = "Pago"> Pago </option>
        </select> <br> <br>
        <input type = "submit" name = "lançar" value = "Lançar" class = "btn btn-primary">
        <a href = "index.php" class = "btn btn-danger"> Retornar </a>
    </form>
</div>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        require "conexao.php";
        $aluno        =  $_POST ['aluno'];
        $mes          =  $_POST ['mes'];
        $curso        =  $_POST ['curso'];
        $valor        =  $_POST ['valor'];
        $vlpagamento  =  $_POST ['vlpagamento'];
        $dtpagamento  =  $_POST ['dtpagamento'];
        $situacao     =  $_POST ['situacao'];

        $sql = "INSERT INTO tbmensalidade (codaluno, mes, curso, valor, vlpagamento, dtpagamento, situacao)";
        $sql .= " VALUES ('$aluno', '$mes', '$curso', '$valor', '$vlpagamento', '$dtpagamento', '$situacao')";

        mysqli_query ($conexao, $sql) or die (mysqli_error($conexao));
        mysqli_close($conexao);
        echo "<script> alert ('Mensalidade cadastrada com sucesso'); </script>";
        echo "<script> window.location.href = window.location.href; </script>";
    }
?>