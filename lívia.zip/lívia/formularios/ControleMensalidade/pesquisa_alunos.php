<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Pesquisa de Alunos </h3>
    <form method = "GET" action = "pesquisa_alunos.php">
        <label> Digite o nome do aluno: </label>
        <input type = "text" name = "nome" size = "40" maxlength = "40" placeholder = "Pressione Enter para pesquisar todos"> <br> <br>
        <input type = "submit" value = "Pesquisar" class = "btn btn-primary">
        <a href = "index.php" class = "btn btn-danger"> Retornar </a>
    </form>

    <?php
    require "conexao.php";

    if (isset($_GET["nome"]))
    {
        $nome = $_GET ["nome"];
        $sql = "SELECT * FROM tbaluno WHERE aluno LIKE '%$nome%' ORDER BY aluno";
        $resultado = mysqli_query ($conexao, $sql) or die (mysqli_error($conexao));

        if (mysqli_num_rows($resultado) > 0)
        {
            echo "<table width = '80%' border = '1' align = 'center'>";
                echo "<tr>";
                    echo "<th align = 'right'> Código </th>";
                    echo "<th> Nome do aluno </th>";
                    echo "<th> Cidade </th>";
                    echo "<th> Email </th>";
                    echo "<th> Editar </th>";
                echo "</tr>";
    
            while ($linha = mysqli_fetch_array($resultado))
            {
                $codigo = $linha ['codigo'];
                $aluno = $linha ['aluno'];
                $cidade = $linha ['cidade'];
                $email = $linha ['email'];
    
                // exibe os dados na tela
                echo "<tr>";
                    echo "<td align = 'right'> $codigo </td>";
                    echo "<td> $aluno </td>";
                    echo "<td> $cidade </td>";
                    echo "<td> $email </td>";
                    echo "<td align = 'center'> <a href = 'editar_aluno.php?codigo=$codigo'> Editar </a> </td>";
                echo "</tr>";
            }

            echo "</table>";
        }
    }
    mysqli_close($conexao);
    ?>
</div>