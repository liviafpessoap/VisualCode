<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class = "container">
    <h3 class = "text-center text-primary"> Pesquisa de Mensalidade </h3>

    <?php
    require "conexao.php";

    $sql = "SELECT tbmensalidade.mensalidade, tbmensalidade.codaluno, tbaluno.aluno, tbmensalidade.mes, tbmensalidade.curso, tbmensalidade.valor, tbmensalidade.vlpagamento, tbmensalidade.dtpagamento, tbmensalidade.situacao FROM tbmensalidade INNER JOIN tbaluno ON tbaluno.codigo = tbmensalidade.codaluno ORDER BY mes";
    $resultado = mysqli_query ($conexao, $sql) or die (mysqli_error($conexao));

    echo "<table width = '100%' border = '1' align = 'center'>";
        echo "<tr>";
            echo "<th align = 'right'> CodMen </th>";
            echo "<th> CodAluno </th>";
            echo "<th> Mês </th>";
            echo "<th> Curso </th>";
            echo "<th> Valor </th>";
            echo "<th> vlPagamento </th>";
            echo "<th> dtPagamento </th>";
            echo "<th> Situação </th>";
            echo "<th> Editar </th>";
        echo "</tr>";
        
    while ($linha = mysqli_fetch_array($resultado))
    {
        $codmen       =  $linha ['mensalidade'];
        $codaluno     =  $linha ['codaluno'];
        $mes          =  $linha ['mes'];
        $curso        =  $linha ['curso'];
        $valor        =  $linha ['valor'];
        $vlpagamento  =  $linha ['vlpagamento'];
        $dtpagamento  =  $linha ['dtpagamento'];
        $situacao     =  $linha ['situacao'];

        $mesExtenso = ObterMesExtenso($mes);

        // exibe os dados na tela
        echo "<tr>";
            echo "<td align = 'right'> $codmen </td>";
            echo "<td align = 'right'> $codaluno </td>";
            echo "<td align = 'right'> $mes </td>";
            echo "<td align = 'right'> $curso </td>";
            echo "<td align = 'right'> $valor </td>";
            echo "<td align = 'right'> $vlpagamento </td>";
            echo "<td align = 'right'> $dtpagamento </td>";
            echo "<td align = 'right'> $situacao </td>";
            echo "<td align = 'center'> <a href = 'editar_mensalidade.php?mensalidade=$codmen' class = 'btn btn-danger'> Editar </a> </td>";
        echo "</tr>";
    }
    echo "</table>";

    function ObterMesExtenso (int $mes): string
    {
        switch ($mes)
        {
            case 1:
                return "Janeiro";
            case 2:
                return "Fevereiro";
            case 3:
                return "Março";
            case 4:
                return "Abril";
            case 5:
                return "Maio";
            case 6:
                return "Junho";
            case 7:
                return "Julho";
            case 8:
                return "Agosto";
            case 9:
                return "Setembro";
            case 10:
                return "Outubro";
            case 11:
                return "Novembro";
            case 12:
                return "Dezembro";
            default:
                return;
        }
    }

    ?>
</div>