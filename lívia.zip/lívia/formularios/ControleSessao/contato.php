<h3> Controle de Sessão </h3>
<h3> FALE CONOSCO </h3>
<tr>
<form name = "contato" method = "POST" action = "">
<label> Nome..:</label>
<input type = "text" name = "nome" size = "50" maxlength = "50" required placeholder = "Informe o nome completo"> <br>
<label> Cidade: </label>
<input type = "text" name = "cidade" size = "30" maxlength = "30" required> <br>
<label> Email: </label>
<input type = "email" name = "email" size = "30" maxlength = "30" required>
<h3> Como ficou sabendo do nosso site? </h3>
<input type = "checkbox" name = "opcao" value = "redes-sociais"> Redes sociais <br>
<input type = "checkbox" name = "opcao" value = "indicacao-amigos"> Indicação de amigos <br>
<input type = "checkbox" name = "opcao" value = "mecanismo-busca"> Mecanismo de busca: <strong> Google, Bing </strong> <br>
Comentários:
<textarea name = "comentarios" cols = "50" rows = "4"> </textarea> <br>
<input type = "submit" name = "enviar" value = "Enviar">
</form>

<?php
echo "<h3> Processando os dados...</h3>";
$nome = $_POST ["nome"];
$cidade = $_POST ["cidade"];

echo "Nome:" .$nome;
echo "<br>";
echo "Cidade:" .$cidade;
echo "<br>";
echo "Email:" .$email;
echo "<br>";
echo "Comentário:" .$comentarios;
?>