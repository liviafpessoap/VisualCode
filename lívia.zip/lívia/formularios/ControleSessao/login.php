<h3>Acesso ao Sistema</h3>
<form name="login" method="POST" action="ValidarLogin.php">
    <label>E-mail:</label>
    <input type="email" name="email" size="30" maxlength="30" required><br><br>
    <label>Senha.:</label>
    <input type="password" name="senha" size="20" maxlength="20" required><br><br>
    <input type="submit" name="acessar" value="Acessar">
</form>