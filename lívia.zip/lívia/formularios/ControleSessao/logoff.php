<?php
session_start();
session_destroy(); // elimina todas as variáveis da sessão
header("Location: index.php");
?>