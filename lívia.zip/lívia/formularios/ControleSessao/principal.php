<?php
error_reporting(0);
session_start();
if (isset {$_SESSION ["email"]}) // se informou o email
{
    $email = $_SESSION ["email"];
    echo "Usuário" .$email;
}
else
{
    echo "Acesso negado, você precisa efetuar login."
    echo "<meta http-equiv='refresh' content='4;url=index.php'>"
}
?>

<h2> Seja bem vindo </h2>
<a href = "sobre.php"> Sobre </a>
<a href = "contato.php"> Contato </a>
<a href = "logoff.php"> Sair </a>