<h3 align = "center"> Validação do Login </h3>
<?php
session_start(); // inicia a sessão
if ($_SERVER ['REQUEST_METHOD'] == 'POST') {
    // armazena nas variáveis os conteúdos informados nas caixas de texto
    $email = $_POST ["email"];
    $senha = $_POST ["senha"];

    if ($email == "usuario@servidor.com" && $senha == "1234") {
        $_SESSION ["email"] = $email;
        header ("Location: principal.php");
    } else {
        echo "Usuário ou senha inválida";
    }
} else {
    header ("Location: login.php");
}
?>