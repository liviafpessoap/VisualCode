<?php
echo "<h4> Média de 4 Notas </h4>";
if ($_SERVER ['REQUEST_METHOD'] == 'POST') {
    // armazena nas variáveis, os dados informados no form
    $aluno = $_POST ["nome"];
    $disciplina = $_POST ["disciplina"];
    $AnoLetivo = $_POST ["AnoLetivo"];
    $nota1 = $_POST ["nota1"];
    $nota2 = $_POST ["nota2"];
    $nota3 = $_POST ["nota3"];
    $nota4 = $_POST ["nota4"];

    // exibe os valores no navegador
    echo "<br> Aluno: " . $aluno;
    echo "<br> Disciplina: " . $disciplina;
    echo "<br> Ano Letivo: " . $AnoLetivo;
    echo "<br> Nota 1: " . $nota1;
    echo "<br> Nota 2: " . $nota2;
    echo "<br> Nota 3: " . $nota3;
    echo "<br> Nota 4: " . $nota4;

    // efetua o cálculo da média
    $media = ($nota1 + $nota2 + $nota3 + $nota4) / 4;
    echo "<hr size='3' color='red' width='30%' align='left'> Média: " . $media;

    // efetua se o aluno foi aprovado ou reprovado
    $situacao = "";
    if ($media >= 6) {
        $situacao = "Aprovado";
    }
    else {
        $situacao = "Reprovado";
    }
    echo "<br> $situacao";
}
?>