<h4 align = "center"> Média de 4 Notas </h4>
<form action = "Exibir_Dados.php" method = "POST">
    <table border = "1" width = "800" align = "center"> 
        <tr>
            <td> <label> informe se nome: </label> </td>
            <td> <input type = "text" name = "nome" size = "40" maxlength = "48" placeholder = "informe seu nome completo" required> <br> </td>
        </tr>
        <tr>
            <td> <label> Disciplina: </label> </td>
            <td> <input type = "text" name = "disciplina" size = "30" maxlength = "30" required> <br> </td>
        </tr>
        <tr>
            <td> <label> Ano letivo: </label> </td>
            <td> <input type = "number" name = "AnoLetivo" min = "2010" max = "2030" required> <br> </td>
        </tr>
        <tr>
            <td> <label> Nota 1: </label> </td>
            <td> <input type = "number" name = "nota1" min = "0" max = "10" required> <br> </td>
        </tr>
        <tr>
            <td> <label> Nota 2: </label> </td>
            <td> <input type = "number" name = "nota2" min = "0" max = "10" required> <br> </td>
        </tr>
        <tr>
            <td> <label> Nota 3: </label> </td>
            <td> <input type = "number" name = "nota3" min = "0" max = "10" required> <br> </td>
        </tr>
        <tr>
             <td> <label> Nota 4: </label> </td>
                <td> <input type = "number" name = "nota4" min = "0" max = "10" required> <br> </td>
        </tr>
        <tr>
            <td colspan = "2" align = "center"> <input type = "submit" value = "Processar" name = "processar"> </td>
        </tr>
    </table>
</form>