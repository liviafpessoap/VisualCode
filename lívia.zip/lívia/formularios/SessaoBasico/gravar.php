<?php
session_start(); // inicia a sessão

if ($_SERVER ['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST ["nome"];

    // grava o conteúdo da variável $nome na sessão
    $_SESSION ["nome"] = $nome;
    echo "<h3> Dados salvos com sucesso </h3>";
    echo "<a href = 'sessao.php'> Voltar </a>";
} else {
    // Redireciona para o formulário DadosPessoais
    header ("Location: sessao.php");
    exit;
}
?>