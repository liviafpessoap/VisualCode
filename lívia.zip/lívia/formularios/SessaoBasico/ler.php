<?php
session_start(); // inicia a sessão

// faz a leitura do dado que está salvo na sessão
$nome = $_SESSION ["nome"];

// exibe o dado salvo na sessão
echo "Nome: " . $nome;
?>