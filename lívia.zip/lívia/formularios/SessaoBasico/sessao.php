<h3> Grava a Sessão </h3>
<form name = "sessão" method = "POST" action = "gravar.php">
    <label> Nome: </label>
    <input type = "text" name = "nome" size = "40" maxlength = "40" required> <br> <br>
    <input type = "submit" name = "gravar" value = "Gravar">
</form>