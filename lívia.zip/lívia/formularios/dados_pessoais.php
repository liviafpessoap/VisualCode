<hr> DADOS PESSOAIS </h3>
<form action = "Exibir_Dados.php" method = "POST">
    <label> Nome..:</label>
    <input type = "text" name = "nome" size = "50" maxlength = "50" required> <br>
    <label> Cidade..:</label>
    <input type = "text" name = "cidade" size = "30" maxlength = "30" required> <br>
    <label> E-mail..:</label>
    <input type = "text" name = "e-mail" size = "30" maxlength = "30" required> <br>
    <label> Idade..:</label>
    <input type = "text" name = "idade" min = "0" max = "150" required> <br> <br>
    <input type = "submit" value = "Exibir" name = "exibir">
    <input type = "reset" value = "Limpar" name = "limpar">
</form>