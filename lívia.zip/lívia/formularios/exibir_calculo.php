<?php
echo "<h3> SOMA DE DOIS NÚMEROS </h3> <hr>";

// as variáveis recebem os valores informados no form
$numero1 = $_POST ["num1"];
$numero2 = $_POST ["num2"];

// soma as duas variáveis
$total = $numero + $numero2;

// exibe as duas variáveis e o resultado
echo "<br> <strong> Numero1: </strong>" $numero1;
echo "<br> <strong> Numero2: </strong>" $numero2;
echo "<br> <strong> Total: </strong>" $total;
?>