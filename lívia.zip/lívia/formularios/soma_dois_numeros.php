<h4> SOMA DE DOIS NÚMEROS </h4>
<form action = "exibir_calculo.php" method = "POST">
<label> Numero1: </label>
<input type = "text" name = "num1" size = "5" maxlength = "4" required> <br>
<label> Numero2: </label>
<input type = "text" name = "num2" size = "5" maxlength = "4" required> <br> <br>
<input type = "submit" value = "Calcular">
<input type = "reset" value = "Limpar">
</form>