<?php
echo "<strong> FUNÇÕES STRING </strong>";
echo "<hr>";
echo "<br> Função <strong> len </strong> <em> obtêm a quantidade de caracteres </em>.";
$linguagem = "<strong> PHP - Linguagem Dinâmica </strong>";
echo "<br> A frase $linguagem tem "
.strlen ($linguagem) . " caracteres.";
echo "<hr>";
echo "<br> Função <strong> strtolower </strong> - converte para minúsculas.";
echo "<br>" . strtolower($linguagem);
echo "<hr>";
echo "<br> Função <strong> strtoupper </strong> - converte para maiúsculas";
echo "<br>" . strtoupper($linguagem);
echo "<hr>";
echo "<br> Função <strong> substr </strong> - extrai uma string de outra string.";
echo "<hr>"
echo "Texto extraído " . substr("Funções string", 0, 2);
?>