<?php
echo "HELLO WORLD"; /* Exibe mensagem na página  */
?>