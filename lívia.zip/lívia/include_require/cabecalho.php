<?php
echo "<3> Função include Require </3>";
$ano = date ("Y");
echo "<h6> &copy; - $ano - Desenvolvido por Lero Lero </h6>";
?>