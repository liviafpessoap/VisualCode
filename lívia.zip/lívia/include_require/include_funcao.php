<?php
include "cabecalho.php" // importa este arquivo para esta pagina
echo "<h5> A diferença entre include e require no PHP é a forma como tratam erros. O require é mais rigoroso e interrompe a execução do script se não encontrar o arquivo especificado. Já o include emite um aviso e continua a execução do script. </h5>"
?>