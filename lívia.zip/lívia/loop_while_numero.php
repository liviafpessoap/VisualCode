<body bgcolor = "green">

<?php
$numero > 0;
while($numero < 100)
{
    $numero++;
    echo $numero . " ";
}
?>