<?php
    echo "OPERADORES MATEMÁTICOS EM PHP - MÉTODO GET";

    $numero1 = $_GET["num1"];
    $numero2 = $_GET["num2"];
    
    echo $numero1;
    echo $numero2;
?>