<hr>
<?php
echo "RAIZ QUADRADA EM <strong>PHP</strong>";
echo "<hr>";
$raiz=64;
echo "<em>raiz quadrada de </em> $raiz é" . sqrt($raiz); // a função sqrt exibe a raiz quadrada de um número informado
echo "<br>Site desenvolvido por Liverton - &copy";
?>