<?php
$titulo = "VARIÁVEL TIPO STRING";
$linguagem = "PHP"; // Definindo a variável do tipo string
echo $titulo;
echo "<hr><br>" . $linguagem;
$tipo = "Linguagem Dinâmica";
echo " " . $tipo;
echo "<hr>";
var_dump($titulo); // Exibe o tipo da variável
?>