<body bgcolor='green'>
<?php
echo "<b>VARIÁVEL TIPO INTEIRO</b><hr>";
$numero1=10;
$numero2=15;
echo "<strong>Número 1: </strong>" .$numero1;
echo "<br><strong>Número 2: </strong>" .$numero2;
$resultado = $numero1 + $numero2;
echo "<hr>";
echo "<br><strong>Soma: </strong>" .$resultado;
echo "<hr>";
$resultado = $numero1 - $numero2;
echo "<br><strong>Subtração: </strong>" .$resultado;
echo "<hr>";
$resultado = $numero1 * $numero2;
echo "<br><strong>Multiplicação: </strong>" .$resultado;
echo "<hr>";
$resultado = $numero1 / $numero2;
echo "<br><strong>Divisão: </strong>" .$resultado;
echo "<hr>";
echo "<marque direction='right'>SEJA BEM-VINDO</marquee>";
echo "<br><marque behavior='alternate'>Obrigado pela visita!</marquee>";
?>